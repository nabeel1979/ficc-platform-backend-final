// ─── Elements ───
const draftIdInput     = document.getElementById('draftId');
const tokenInput       = document.getElementById('token');
const scanFolderInput  = document.getElementById('scanFolder');
const naps2PathInput   = document.getElementById('naps2Path');
const toggleTokenBtn   = document.getElementById('toggleToken');
const saveConfigBtn    = document.getElementById('saveConfig');
const openNAPS2Btn     = document.getElementById('openNAPS2');
const startMonitorBtn  = document.getElementById('startMonitoring');
const stopMonitorBtn   = document.getElementById('stopMonitoring');
const statusDiv        = document.getElementById('status');
const filesListDiv     = document.getElementById('filesList');
const uploadProgressDiv= document.getElementById('uploadProgress');

let monitoringActive  = false;
let monitoringInterval = null;
let uploadedFiles     = new Set(); // لتجنب رفع نفس الملف مرتين

// ─── Init ───
async function init() {
  if (!window.electronAPI) {
    updateStatus('❌ electronAPI غير متوفر', 'error');
    return;
  }

  try {
    const config = await window.electronAPI.getConfig();
    draftIdInput.value   = config.draftId   || '';
    tokenInput.value     = config.token     || '';
    scanFolderInput.value= config.scanFolder|| 'E:\\scaner';
    naps2PathInput.value = config.naps2Path || 'C:\\Program Files\\NAPS2\\NAPS2.exe';

    // عرض حالة NAPS2
    const naps2Status = config.naps2Detected !== false
      ? `✅ تم اكتشاف NAPS2: ${config.naps2Path}`
      : `⚠️ لم يتم اكتشاف NAPS2 — تحقق من المسار`
    updateStatus(naps2Status, config.naps2Detected !== false ? 'success' : 'warning');
  } catch (err) {
    updateStatus('❌ خطأ: ' + err.message, 'error');
  }
}

// ─── Toggle Token ───
toggleTokenBtn.addEventListener('click', () => {
  tokenInput.type = tokenInput.type === 'password' ? 'text' : 'password';
  toggleTokenBtn.textContent = tokenInput.type === 'password' ? '👁️' : '🙈';
});

// ─── Save Config ───
saveConfigBtn.addEventListener('click', async () => {
  await window.electronAPI.saveConfig({
    draftId:    draftIdInput.value,
    token:      tokenInput.value,
    scanFolder: scanFolderInput.value,
    naps2Path:  naps2PathInput.value,
    apiUrl:     'https://ficc.iq'
  });
  updateStatus('✅ تم حفظ الإعدادات');
});

// ─── Open NAPS2 ───
openNAPS2Btn.addEventListener('click', async () => {
  if (!draftIdInput.value || !tokenInput.value) {
    updateStatus('⚠️ أدخل Token و Draft ID أولاً!', 'warning');
    return;
  }

  updateStatus('⏳ جاري فتح NAPS2...');
  const result = await window.electronAPI.openNAPS2({
    naps2Path: naps2PathInput.value,
    draftId:   draftIdInput.value
  });

  if (result.success) {
    updateStatus('✅ NAPS2 مفتوح — امسح الوثيقة ثم ستُرفع تلقائياً!');
    // ابدأ مراقبة المجلد تلقائياً
    startMonitor();
  } else {
    updateStatus('❌ تعذّر فتح NAPS2: ' + result.error, 'error');
  }
});

// ─── Start Monitor ───
startMonitorBtn.addEventListener('click', () => {
  if (!draftIdInput.value || !tokenInput.value) {
    updateStatus('⚠️ أدخل Token و Draft ID أولاً!', 'warning');
    return;
  }
  startMonitor();
});

// ─── Stop Monitor ───
stopMonitorBtn.addEventListener('click', stopMonitor);

// ─── Monitor Functions ───
function startMonitor() {
  if (monitoringActive) return;
  monitoringActive = true;
  startMonitorBtn.disabled = true;
  stopMonitorBtn.disabled  = false;
  updateStatus('🔄 جاري المراقبة — انتظر الملفات الجديدة...');
  monitoringInterval = setInterval(checkNewFiles, 2000);
}

function stopMonitor() {
  monitoringActive = false;
  clearInterval(monitoringInterval);
  startMonitorBtn.disabled = false;
  stopMonitorBtn.disabled  = true;
  updateStatus('⏹️ توقفت المراقبة');
}

async function checkNewFiles() {
  const result = await window.electronAPI.monitorFolder({
    scanFolder: scanFolderInput.value,
    draftId:    draftIdInput.value,
    token:      tokenInput.value
  });

  if (!result.success || !result.files.length) return;

  // فلتر الملفات الجديدة فقط
  const newFiles = result.files.filter(f => !uploadedFiles.has(f));
  if (!newFiles.length) return;

  // عرض الملفات
  filesListDiv.innerHTML = result.files.map(f => {
    const name = f.split('\\').pop();
    const isNew = !uploadedFiles.has(f);
    return `<div style="padding:6px 0;border-bottom:1px solid #eee;font-size:13px;color:${isNew?'#2C3E6B':'#aaa'}">
      ${isNew ? '🆕' : '✅'} ${name}
    </div>`;
  }).join('');

  // ارفع الملفات الجديدة
  for (const filePath of newFiles) {
    const fileName = filePath.split('\\').pop();
    updateStatus(`📤 جاري رفع ${fileName}...`);
    uploadProgressDiv.innerHTML = `<div style="padding:8px;background:#EEF2FF;border-radius:8px;font-size:13px;color:#2C3E6B">⏳ رفع ${fileName}...</div>`;

    const res = await window.electronAPI.uploadFile({
      filePath,
      draftId:  draftIdInput.value,
      token:    tokenInput.value,
      apiUrl:   'https://ficc.iq'
    });

    if (res.success) {
      uploadedFiles.add(filePath);
      uploadProgressDiv.innerHTML += `<div style="padding:8px;background:#F0FDF4;border-radius:8px;font-size:13px;color:#16a34a;margin-top:4px">✅ تم رفع ${fileName} بنجاح!</div>`;
      updateStatus(`✅ تم رفع ${fileName} — يمكنك متابعة المسح`);
    } else {
      uploadProgressDiv.innerHTML += `<div style="padding:8px;background:#FEF2F2;border-radius:8px;font-size:13px;color:#dc2626;margin-top:4px">❌ فشل رفع ${fileName}: ${res.error}</div>`;
      updateStatus(`❌ فشل رفع ${fileName}`, 'error');
    }
  }

  // أوقف المراقبة بعد رفع الملفات
  if (newFiles.length > 0) {
    setTimeout(stopMonitor, 3000);
  }
}

// ─── Status Helper ───
function updateStatus(msg, type = 'success') {
  statusDiv.textContent = msg;
  statusDiv.style.background = type === 'error' ? '#FEF2F2' : type === 'warning' ? '#FFF8E7' : '#F0FDF4';
  statusDiv.style.color      = type === 'error' ? '#dc2626' : type === 'warning' ? '#B8860B' : '#16a34a';
  statusDiv.style.padding    = '12px 16px';
  statusDiv.style.borderRadius = '10px';
  statusDiv.style.fontFamily = 'Cairo, sans-serif';
  statusDiv.style.fontSize   = '14px';
  statusDiv.style.fontWeight = '600';
}

// ─── Handle Protocol URL (ficc-scanner://scan?draftId=X&token=Y) ───
if (window.electronAPI?.onProtocolUrl) {
  window.electronAPI.onProtocolUrl((url) => {
    try {
      const params = new URL(url).searchParams;
      const draftId = params.get('draftId');
      const token   = params.get('token');
      if (draftId) draftIdInput.value = draftId;
      if (token)   tokenInput.value   = token;
      // احفظ وابدأ مباشرة
      window.electronAPI.saveConfig({
        draftId, token,
        scanFolder: scanFolderInput.value,
        naps2Path:  naps2PathInput.value,
        apiUrl:     'https://ficc.iq'
      });
      // افتح NAPS2 مباشرة
      openNAPS2Btn.click();
    } catch (e) {
      console.error('Protocol URL error:', e);
    }
  });
}

// ─── Start ───
init();
